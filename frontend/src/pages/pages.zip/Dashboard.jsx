import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import Layout from "../components/Layout";
import api from "../services/api";
import { Card, Button, Alert } from "../components/ui";
import { useAuth } from "../context/AuthContext";

function dateKey(dateLike) {
  const d = new Date(dateLike);
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function Calendar({ currentMonth, selectedDate, groupedDates, onSelectDate, onPrev, onNext }) {
  const year = currentMonth.getFullYear();
  const month = currentMonth.getMonth();
  const firstDay = new Date(year, month, 1);
  const startWeekday = firstDay.getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const cells = [];
  for (let i = 0; i < startWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(year, month, d));

  return (
    <Card>
      <div className="mb-4 flex items-center justify-between">
        <button onClick={onPrev} className="btn">‹</button>
        <div className="text-white font-semibold">
          {currentMonth.toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}
        </div>
        <button onClick={onNext} className="btn">›</button>
      </div>

      <div className="grid grid-cols-7 text-xs text-slate-400 mb-2">
        {["Dom","Seg","Ter","Qua","Qui","Sex","Sáb"].map(d => <div key={d}>{d}</div>)}
      </div>

      <div className="grid grid-cols-7 gap-2">
        {cells.map((cell, i) => {
          if (!cell) return <div key={i} />;
          const key = dateKey(cell);
          const has = groupedDates[key]?.length;

          return (
            <button
              key={key}
              onClick={() => onSelectDate(cell)}
              className="h-10 rounded bg-white/5 text-white"
            >
              {cell.getDate()}
              {has ? <div className="w-1 h-1 bg-green-400 rounded-full mx-auto mt-1" /> : null}
            </button>
          );
        })}
      </div>
    </Card>
  );
}

function Stat({ title, value }) {
  return (
    <Card>
      <div className="text-slate-400 text-sm">{title}</div>
      <div className="text-white text-2xl font-bold mt-2">{value}</div>
    </Card>
  );
}

function money(v) {
  return Number(v || 0).toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  });
}

export default function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [imoveis, setImoveis] = useState([]);
  const [visitas, setVisitas] = useState([]);
  const [negociacoes, setNegociacoes] = useState([]);
  const [error, setError] = useState("");

  const [selectedDate, setSelectedDate] = useState(new Date());
  const [month, setMonth] = useState(new Date());

  async function load() {
    try {
      const [i, v, n] = await Promise.all([
        api.get("/imoveis/"),
        api.get("/visitas/"),
        api.get("/negociacoes/"),
      ]);

      setImoveis(i.data);
      setVisitas(v.data);
      setNegociacoes(n.data);
    } catch {
      setError("Erro ao carregar dados");
    }
  }

  useEffect(() => {
    load();
  }, []);

  const grouped = useMemo(() => {
    return visitas.reduce((acc, v) => {
      const k = dateKey(v.data_visita);
      if (!acc[k]) acc[k] = [];
      acc[k].push(v);
      return acc;
    }, {});
  }, [visitas]);

  const hoje = dateKey(new Date());

  const hojeLista = grouped[hoje] || [];

  const totalImoveis = useMemo(() => {
    return imoveis.reduce((a, i) => a + Number(i.valor || 0), 0);
  }, [imoveis]);

  const totalNegociacoes = useMemo(() => {
    return negociacoes.reduce((a, n) => a + Number(n.valor_negociado || 0), 0);
  }, [negociacoes]);

  const totalComissao = useMemo(() => {
    return negociacoes.reduce((a, n) => a + Number(n.valor_lucro || 0), 0);
  }, [negociacoes]);

  return (
    <Layout>
      <div className="flex justify-between mb-6 flex-wrap gap-3">
        <div>
          <h1 className="text-white text-2xl font-bold">Dashboard</h1>
          <p className="text-slate-400">Resumo do sistema</p>
        </div>

        <div className="flex gap-2 flex-wrap">
          <Button onClick={() => navigate("/visitas")}>Agenda</Button>

          {user?.perfil !== "atendente" && (
            <Button onClick={() => navigate("/negociacoes")}>Negociações</Button>
          )}

          {String(user?.perfil).toLowerCase() === "admin" && (
            <Button onClick={() => navigate("/corretores")}>Corretores</Button>
          )}
        </div>
      </div>

      {error && <Alert>{error}</Alert>}

      {hojeLista.length > 0 && (
        <Alert>
          Você tem {hojeLista.length} compromisso(s) hoje
        </Alert>
      )}

      <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-4">
        <Stat title="Imóveis" value={money(totalImoveis)} />
        <Stat title="Negociações" value={money(totalNegociacoes)} />
        <Stat title="Comissão" value={money(totalComissao)} />
        <Stat title="Hoje" value={hojeLista.length} />
      </div>

      <div className="grid xl:grid-cols-2 gap-6 mt-6">
        <Calendar
          currentMonth={month}
          selectedDate={selectedDate}
          groupedDates={grouped}
          onSelectDate={setSelectedDate}
          onPrev={() => setMonth(new Date(month.getFullYear(), month.getMonth() - 1, 1))}
          onNext={() => setMonth(new Date(month.getFullYear(), month.getMonth() + 1, 1))}
        />

        <Card>
          <h2 className="text-white mb-3">Agenda do dia</h2>

          {(grouped[dateKey(selectedDate)] || []).map((v) => (
            <div key={v.id} className="mb-2 text-slate-300">
              {new Date(v.data_visita).toLocaleTimeString("pt-BR")} - {v.tipo}
            </div>
          ))}
        </Card>
      </div>
    </Layout>
  );
}