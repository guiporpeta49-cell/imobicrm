import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Layout from "../components/Layout";
import api from "../services/api";
import { Button, Card } from "../components/ui";

function fmtCurrency(value) {
  return Number(value || 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function InfoCard({ label, value }) {
  return (
    <div className="rounded-2xl bg-white/[0.03] p-4">
      <div className="text-xs uppercase tracking-wide text-slate-400">{label}</div>
      <div className="mt-1 font-semibold text-white">{value ?? "-"}</div>
    </div>
  );
}

export default function ImovelDetalhe() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [imovel, setImovel] = useState(null);
  const [midias, setMidias] = useState([]);
  const [selected, setSelected] = useState(null);
  const [loadingShare, setLoadingShare] = useState(false);

  // 🔥 NOVO
  const [openPreview, setOpenPreview] = useState(false);

  async function load() {
    const res1 = await api.get(`/imoveis/${id}`);
    const res2 = await api.get(`/imoveis/${id}/midias`);
    setImovel(res1.data);
    setMidias(res2.data);
    if (res2.data.length) setSelected(res2.data[0]);
  }

  useEffect(() => { load(); }, [id]);

  async function handleWhatsApp() {
    try {
      setLoadingShare(true);
      const response = await api.get(`/imoveis/${id}/compartilhar`);
      window.open(response.data.whatsapp_url, "_blank");
    } catch (err) {
      alert(err?.response?.data?.detail || "Erro ao gerar compartilhamento");
    } finally {
      setLoadingShare(false);
    }
  }

  function handlePdf() {
    window.open(`http://127.0.0.1:8000/imoveis/${id}/pdf`, "_blank");
  }

  if (!imovel) {
    return <Layout><Card>Carregando...</Card></Layout>;
  }

  return (
    <Layout>
      <div className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <Button variant="secondary" onClick={() => navigate(-1)}>Voltar</Button>
        <div className="flex w-full flex-col gap-3 sm:w-auto sm:flex-row sm:flex-wrap">
          <Button variant="success" onClick={handleWhatsApp} disabled={loadingShare}>
            {loadingShare ? "Gerando..." : "Enviar no WhatsApp"}
          </Button>
          <Button onClick={handlePdf}>Gerar PDF</Button>
          <Button onClick={() => navigate(`/negociacoes?imovel_id=${id}`)}>Criar proposta</Button>
          <Button variant="success" onClick={() => navigate(`/visitas?imovel_id=${id}`)}>
            Agendar visita
          </Button>
        </div>
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.45fr_0.8fr]">
        <Card>
          {/* 🔥 CLICK PARA EXPANDIR */}
          <div
            className="overflow-hidden rounded-3xl bg-slate-100 cursor-pointer"
            onClick={() => selected && setOpenPreview(true)}
          >
            {selected && selected.tipo === "foto" ? (
              <img
                src={`http://127.0.0.1:8000${selected.arquivo_url}`}
                alt={selected.nome_arquivo}
                className="h-[260px] w-full object-cover sm:h-[360px] xl:h-[440px]"
              />
            ) : selected ? (
              <video
                controls
                src={`http://127.0.0.1:8000${selected.arquivo_url}`}
                className="h-[260px] w-full object-cover sm:h-[360px] xl:h-[440px]"
              />
            ) : (
              <div className="flex h-[440px] items-center justify-center text-slate-400">
                Sem mídia cadastrada
              </div>
            )}
          </div>

          <div className="mt-4 flex flex-wrap gap-2 sm:gap-3">
            {midias.map((m) => (
              <button
                key={m.id}
                onClick={() => {
                  setSelected(m);
                  setOpenPreview(true); // 🔥 abre ao clicar
                }}
                className={`overflow-hidden rounded-2xl border-2 ${
                  selected?.id === m.id ? "border-blue-600" : "border-transparent"
                }`}
              >
                {m.tipo === "foto" ? (
                  <img
                    src={`http://127.0.0.1:8000${m.arquivo_url}`}
                    alt={m.nome_arquivo}
                    className="h-20 w-28 object-cover"
                  />
                ) : (
                  <video
                    src={`http://127.0.0.1:8000${m.arquivo_url}`}
                    className="h-20 w-28 object-cover"
                  />
                )}
              </button>
            ))}
          </div>
        </Card>

        <div className="space-y-6">
          <Card>
            <h1 className="text-3xl font-bold tracking-tight text-white">{imovel.titulo}</h1>
            <div className="mt-3 text-3xl font-extrabold text-blue-300">
              {fmtCurrency(imovel.valor)}
            </div>
            <p className="mt-3 text-sm text-slate-400">
              {imovel.endereco} {imovel.bairro ? `• ${imovel.bairro}` : ""}{" "}
              {imovel.cidade ? `• ${imovel.cidade}` : ""}
            </p>
          </Card>

          <Card>
            <h2 className="text-lg font-semibold text-white">Informações do imóvel</h2>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <InfoCard label="Tipo" value={imovel.tipo} />
              <InfoCard label="Finalidade" value={imovel.finalidade} />
              <InfoCard label="Quartos" value={imovel.quartos} />
              <InfoCard label="Banheiros" value={imovel.banheiros} />
              <InfoCard label="Vagas" value={imovel.vagas} />
              <InfoCard label="Status" value={imovel.status} />
            </div>
          </Card>

          <Card>
            <h2 className="text-lg font-semibold text-white">Informações rurais</h2>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <InfoCard label="Área em hectares" value={imovel.area_hectares} />
              <InfoCard label="Área em alqueires" value={imovel.area_alqueires} />
              <InfoCard label="Distância do asfalto (km)" value={imovel.distancia_asfalto_km} />
              <InfoCard label="Distância da cidade (km)" value={imovel.distancia_cidade_km} />
              <InfoCard label="Área agricultável" value={imovel.area_agricultavel} />
              <InfoCard label="Área inaproveitável" value={imovel.area_inaproveitavel} />
            </div>
          </Card>
        </div>
      </div>

      <div className="mt-6">
        <Card>
          <h2 className="text-lg font-semibold text-white">Descrição</h2>
          <p className="mt-4 leading-7 text-slate-300">
            {imovel.descricao || "Sem descrição cadastrada."}
          </p>
        </Card>
      </div>

      <div className="mt-6">
        <Card>
          <h2 className="text-lg font-semibold text-white">Plantio existente</h2>
          <p className="mt-4 leading-7 text-slate-300">
            {imovel.plantio_existente || "Não informado."}
          </p>
        </Card>
      </div>

      {/* 🔥 MODAL DE PREVIEW */}
      {openPreview && selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4">
          <button
            onClick={() => setOpenPreview(false)}
            className="absolute right-6 top-6 rounded-2xl bg-white/10 px-4 py-2 text-white"
          >
            Fechar
          </button>

          <div className="max-h-[90vh] max-w-[95vw]">
            {selected.tipo === "foto" ? (
              <img
                src={`http://127.0.0.1:8000${selected.arquivo_url}`}
                className="max-h-[90vh] max-w-[95vw] rounded-2xl object-contain"
              />
            ) : (
              <video
                controls
                autoPlay
                src={`http://127.0.0.1:8000${selected.arquivo_url}`}
                className="max-h-[90vh] max-w-[95vw] rounded-2xl"
              />
            )}
          </div>
        </div>
      )}
    </Layout>
  );
}