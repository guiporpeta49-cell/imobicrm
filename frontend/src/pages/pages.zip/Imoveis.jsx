import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import Layout from "../components/Layout";
import Modal from "../components/Modal";
import api from "../services/api";
import { useAuth } from "../context/AuthContext";
import UploadMidiaImovel from "../components/UploadMidiaImovel";
import GaleriaImovel from "../components/GaleriaImovel";
import {
  PageHeader,
  Button,
  Field,
  Input,
  Select,
  Textarea,
  Alert,
  StatusBadge,
} from "../components/ui";

function formatCurrency(value) {
  const number = String(value || "").replace(/\D/g, "");
  const amount = Number(number) / 100;

  return amount.toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  });
}

const initialForm = {
  titulo: "",
  descricao: "",
  tipo: "apartamento",
  finalidade: "venda",
  endereco: "",
  bairro: "",
  cidade: "",
  valor: "",
  quartos: 0,
  banheiros: 0,
  vagas: 0,
  corretor_id: "",
  area_hectares: "",
  area_alqueires: "",
  distancia_asfalto_km: "",
  distancia_cidade_km: "",
  area_agricultavel: "",
  area_inaproveitavel: "",
  plantio_existente: "",
  nome_proprietario: "",
  telefone_proprietario: "",
};

function fmtCurrency(value) {
  return Number(value || 0).toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  });
}

function InfoBox({ label, value }) {
  return (
    <div className="rounded-2xl border border-white/8 bg-white/[0.03] px-4 py-3 text-sm">
      <div className="text-slate-400">{label}</div>
      <div className="mt-1 font-semibold text-white">{value}</div>
    </div>
  );
}

export default function ImoveisPage() {
  const navigate = useNavigate();
  const [items, setItems] = useState([]);
  const [corretores, setCorretores] = useState([]);
  const [form, setForm] = useState(initialForm);
  const [editingId, setEditingId] = useState(null);
  const [openForm, setOpenForm] = useState(false);
  const [reloadMidiaKey, setReloadMidiaKey] = useState(0);
  const [search, setSearch] = useState("");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const { isAdmin, user } = useAuth();

  async function loadItems() {
    try {
      const response = await api.get("/imoveis/");
      setItems(response.data);
    } catch (err) {
      setError(err?.response?.data?.detail || "Erro ao carregar imóveis");
    }
  }

  async function loadCorretores() {
    try {
      const response = await api.get("/corretores/");
      setCorretores(response.data);
    } catch {}
  }

  useEffect(() => {
    loadItems();
    if (isAdmin) loadCorretores();
  }, [isAdmin]);

  function handleChange(e) {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  }

  function handleCurrencyChange(e) {
    const formatted = formatCurrency(e.target.value);
    setForm((prev) => ({ ...prev, valor: formatted }));
  }

  function resetForm() {
    setForm(initialForm);
    setEditingId(null);
    setReloadMidiaKey(0);
  }

  function openNew() {
    resetForm();
    setError("");
    setMessage("");
    setOpenForm(true);
  }

  function closeModal() {
    setOpenForm(false);
    resetForm();
  }

  function handleUploadedMidia() {
    setReloadMidiaKey((prev) => prev + 1);
    loadItems();
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setMessage("");

    const payload = {
      ...form,
      valor: Number(String(form.valor || "").replace(/\D/g, "")) / 100,
      quartos: Number(form.quartos || 0),
      banheiros: Number(form.banheiros || 0),
      vagas: Number(form.vagas || 0),
      corretor_id: form.corretor_id ? Number(form.corretor_id) : (isAdmin ? null : user?.id || null),
      descricao: form.descricao || null,
      bairro: form.bairro || null,
      cidade: form.cidade || null,
      area_hectares: form.area_hectares ? Number(form.area_hectares) : null,
      area_alqueires: form.area_alqueires ? Number(form.area_alqueires) : null,
      distancia_asfalto_km: form.distancia_asfalto_km ? Number(form.distancia_asfalto_km) : null,
      distancia_cidade_km: form.distancia_cidade_km ? Number(form.distancia_cidade_km) : null,
      area_agricultavel: form.area_agricultavel ? Number(form.area_agricultavel) : null,
      area_inaproveitavel: form.area_inaproveitavel ? Number(form.area_inaproveitavel) : null,
      plantio_existente: form.plantio_existente || null,
      nome_proprietario: form.nome_proprietario || null,
      telefone_proprietario: form.telefone_proprietario || null,
    };

    try {
      if (editingId) {
        await api.put(`/imoveis/${editingId}`, payload);
        setMessage("Imóvel atualizado com sucesso");
      } else {
        const response = await api.post("/imoveis/", payload);
        const novoId = response?.data?.id;
        setMessage("Imóvel cadastrado com sucesso. Agora você já pode enviar mídias.");
        if (novoId) setEditingId(novoId);
      }

      await loadItems();
      closeModal();
    } catch (err) {
      setError(err?.response?.data?.detail || "Erro ao salvar imóvel");
    }
  }

  function handleEdit(item) {
    setEditingId(item.id);
    setForm({
      titulo: item.titulo ?? "",
      descricao: item.descricao ?? "",
      tipo: item.tipo ?? "apartamento",
      finalidade: item.finalidade ?? "venda",
      endereco: item.endereco ?? "",
      bairro: item.bairro ?? "",
      cidade: item.cidade ?? "",
      valor: item.valor ? fmtCurrency(item.valor) : "",
      quartos: item.quartos ?? 0,
      banheiros: item.banheiros ?? 0,
      vagas: item.vagas ?? 0,
      corretor_id: item.corretor_id ?? "",
      area_hectares: item.area_hectares ?? "",
      area_alqueires: item.area_alqueires ?? "",
      distancia_asfalto_km: item.distancia_asfalto_km ?? "",
      distancia_cidade_km: item.distancia_cidade_km ?? "",
      area_agricultavel: item.area_agricultavel ?? "",
      area_inaproveitavel: item.area_inaproveitavel ?? "",
      plantio_existente: item.plantio_existente ?? "",
      nome_proprietario: item.nome_proprietario ?? "",
      telefone_proprietario: item.telefone_proprietario ?? "",
    });
    setError("");
    setMessage("");
    setReloadMidiaKey(0);
    setOpenForm(true);
  }

  async function handleDelete(id) {
    if (!window.confirm("Deseja excluir este imóvel?")) return;

    try {
      await api.delete(`/imoveis/${id}`);
      setMessage("Imóvel removido com sucesso");
      loadItems();
    } catch (err) {
      setError(err?.response?.data?.detail || "Erro ao excluir imóvel");
    }
  }

  const filteredItems = useMemo(() => {
    const term = search.toLowerCase().trim();
    if (!term) return items;
    return items.filter((item) =>
      [
        item.titulo,
        item.tipo,
        item.finalidade,
        item.cidade,
        item.bairro,
        item.status,
        item.plantio_existente,
        item.nome_proprietario,
        item.telefone_proprietario,
      ]
        .filter(Boolean)
        .some((v) => String(v).toLowerCase().includes(term))
    );
  }, [items, search]);

  return (
    <Layout>
      <PageHeader
        title="Imóveis"
        subtitle="Gerencie sua carteira de imóveis."
        actions={
          <div className="flex w-full flex-col gap-3 sm:w-auto sm:flex-row sm:flex-wrap">
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar imóvel..." className="w-full sm:w-72" />
            <Button onClick={openNew}>Novo imóvel</Button>
          </div>
        }
      />

      {error ? <Alert>{error}</Alert> : null}
      {message ? <Alert type="success">{message}</Alert> : null}

      <div className="grid gap-6">
        {filteredItems.map((item) => (
          <div key={item.id} className="overflow-hidden rounded-[2rem] border border-cyan-900/40 bg-[#071526]/88 shadow-[0_15px_40px_rgba(0,0,0,0.28)] backdrop-blur-sm">
            <div className="p-6">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h3 className="text-2xl font-semibold text-white">{item.titulo}</h3>
                  <p className="mt-2 text-sm text-slate-400">{item.cidade || "Cidade"} • {item.bairro || "Bairro"}</p>
                </div>
                <StatusBadge value={item.status} />
              </div>

              <div className="mt-5 text-4xl font-bold tracking-tight text-white">{fmtCurrency(item.valor)}</div>

              <div className="mt-6 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                <InfoBox label="Tipo" value={item.tipo} />
                <InfoBox label="Finalidade" value={item.finalidade} />
                <InfoBox label="Quartos" value={item.quartos} />
                <InfoBox label="Vagas" value={item.vagas} />
                <InfoBox label="Proprietário" value={item.nome_proprietario || "-"} />
                <InfoBox label="WhatsApp / Telefone" value={item.telefone_proprietario || "-"} />
                {item.tipo === "fazenda" ? (
                  <>
                    <InfoBox label="Hectares" value={item.area_hectares ?? "-"} />
                    <InfoBox label="Alqueires" value={item.area_alqueires ?? "-"} />
                    <InfoBox label="Área agricultável" value={item.area_agricultavel ?? "-"} />
                    <InfoBox label="Plantio" value={item.plantio_existente || "-"} />
                  </>
                ) : null}
              </div>

              <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
                <Button variant="secondary" onClick={() => handleEdit(item)}>Editar</Button>
                <Button onClick={() => navigate(`/imoveis/${item.id}`)}>Ver detalhes</Button>
                {isAdmin ? <Button variant="danger" onClick={() => handleDelete(item.id)}>Excluir</Button> : null}
              </div>
            </div>
          </div>
        ))}
      </div>

      <Modal open={openForm} onClose={closeModal} title={editingId ? "Editar imóvel" : "Novo imóvel"} maxWidth="max-w-6xl">
        <div className="space-y-6">
          <form onSubmit={handleSubmit} className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            <div className="xl:col-span-2">
              <Field label="Título"><Input name="titulo" value={form.titulo} onChange={handleChange} required /></Field>
            </div>

            <Field label="Tipo">
              <Select name="tipo" value={form.tipo} onChange={handleChange}>
                <option value="casa">Casa</option>
                <option value="apartamento">Apartamento</option>
                <option value="terreno">Terreno</option>
                <option value="comercial">Comercial</option>
                <option value="fazenda">Fazenda</option>
              </Select>
            </Field>

            <Field label="Finalidade">
              <Select name="finalidade" value={form.finalidade} onChange={handleChange}>
                <option value="venda">Venda</option>
                <option value="aluguel">Aluguel</option>
              </Select>
            </Field>

            <Field label="Valor">
              <Input
                name="valor"
                type="text"
                value={form.valor}
                onChange={handleCurrencyChange}
                placeholder="R$ 0,00"
                required
              />
            </Field>

            <div className="xl:col-span-2">
              <Field label="Endereço"><Input name="endereco" value={form.endereco} onChange={handleChange} required /></Field>
            </div>

            <Field label="Bairro"><Input name="bairro" value={form.bairro} onChange={handleChange} /></Field>
            <Field label="Cidade"><Input name="cidade" value={form.cidade} onChange={handleChange} /></Field>

            <Field label="Nome do proprietário">
              <Input name="nome_proprietario" value={form.nome_proprietario} onChange={handleChange} />
            </Field>

            <Field label="WhatsApp / Telefone do proprietário">
              <Input name="telefone_proprietario" value={form.telefone_proprietario} onChange={handleChange} />
            </Field>

            <Field label="Quartos"><Input name="quartos" type="number" value={form.quartos} onChange={handleChange} /></Field>
            <Field label="Banheiros"><Input name="banheiros" type="number" value={form.banheiros} onChange={handleChange} /></Field>
            <Field label="Vagas"><Input name="vagas" type="number" value={form.vagas} onChange={handleChange} /></Field>

            {isAdmin ? (
              <Field label="Corretor">
                <Select name="corretor_id" value={form.corretor_id} onChange={handleChange}>
                  <option value="">Sem corretor</option>
                  {corretores.map((c) => <option key={c.id} value={c.id}>{c.nome}</option>)}
                </Select>
              </Field>
            ) : null}

            <div className="md:col-span-2 xl:col-span-4">
              <Field label="Descrição"><Textarea name="descricao" rows="4" value={form.descricao} onChange={handleChange} /></Field>
            </div>

            <div className="md:col-span-2 xl:col-span-4 mt-2">
              <div className="rounded-2xl border border-white/8 bg-white/[0.03] px-4 py-3 text-sm font-semibold text-white">
                Informações rurais / fazenda
              </div>
            </div>

            <Field label="Área em hectares"><Input name="area_hectares" type="number" step="0.01" value={form.area_hectares} onChange={handleChange} /></Field>
            <Field label="Área em alqueires"><Input name="area_alqueires" type="number" step="0.01" value={form.area_alqueires} onChange={handleChange} /></Field>
            <Field label="Distância do asfalto (km)"><Input name="distancia_asfalto_km" type="number" step="0.01" value={form.distancia_asfalto_km} onChange={handleChange} /></Field>
            <Field label="Distância da cidade (km)"><Input name="distancia_cidade_km" type="number" step="0.01" value={form.distancia_cidade_km} onChange={handleChange} /></Field>
            <Field label="Área agricultável"><Input name="area_agricultavel" type="number" step="0.01" value={form.area_agricultavel} onChange={handleChange} /></Field>
            <Field label="Área inaproveitável"><Input name="area_inaproveitavel" type="number" step="0.01" value={form.area_inaproveitavel} onChange={handleChange} /></Field>

            <div className="md:col-span-2 xl:col-span-4">
              <Field label="Plantio existente"><Textarea name="plantio_existente" rows="3" value={form.plantio_existente} onChange={handleChange} /></Field>
            </div>

            {editingId ? (
              <div className="md:col-span-2 xl:col-span-4 grid gap-6 xl:grid-cols-2">
                <div className="rounded-[1.5rem] border border-white/8 bg-white/[0.03] p-4">
                  <div className="text-sm font-semibold text-white">Upload de mídia</div>
                  <p className="mt-1 text-sm text-slate-400">Envie fotos e vídeos deste imóvel.</p>
                  <div className="mt-4 text-slate-300">
                    <UploadMidiaImovel imovelId={editingId} onUpload={handleUploadedMidia} />
                  </div>
                </div>

                <div className="rounded-[1.5rem] border border-white/8 bg-white/[0.02] p-4">
                  <div className="text-sm font-semibold text-white">Galeria do imóvel</div>
                  <p className="mt-1 text-sm text-slate-400">As mídias ficam vinculadas ao cadastro deste imóvel.</p>
                  <div className="mt-4 text-slate-300" key={reloadMidiaKey}>
                    <GaleriaImovel imovelId={editingId} />
                  </div>
                </div>
              </div>
            ) : (
              <div className="md:col-span-2 xl:col-span-4 rounded-[1.5rem] border border-dashed border-white/10 bg-white/[0.02] p-5 text-sm text-slate-400">
                Salve o imóvel primeiro para liberar o envio de fotos e vídeos.
              </div>
            )}

            {error ? <div className="md:col-span-2 xl:col-span-4"><Alert>{error}</Alert></div> : null}
            {message ? <div className="md:col-span-2 xl:col-span-4"><Alert type="success">{message}</Alert></div> : null}

            <div className="md:col-span-2 xl:col-span-4 sticky bottom-0 border-t border-white/10 bg-[#071526] pt-4">
              <div className="flex flex-wrap justify-end gap-3">
                <Button type="button" variant="secondary" onClick={closeModal}>Cancelar</Button>
                <Button type="submit">{editingId ? "Atualizar" : "Salvar"}</Button>
              </div>
            </div>
          </form>
        </div>
      </Modal>
    </Layout>
  );
}