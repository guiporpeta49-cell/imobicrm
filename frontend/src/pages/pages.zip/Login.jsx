import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setErro("");
    setLoading(true);

    try {
      await login(email, senha);
      navigate("/");
    } catch (error) {
      setErro(error?.response?.data?.detail || "Erro ao fazer login");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-100 px-4">
      <div className="grid w-full max-w-6xl overflow-hidden rounded-[2rem] bg-white shadow-2xl lg:grid-cols-2">
        <div className="hidden bg-slate-950 p-10 text-white lg:block">
          <div className="text-3xl font-bold">ImobiCRM</div>
          <p className="mt-4 max-w-md text-slate-300">
            Plataforma profissional para gestão de imóveis, clientes, visitas, corretores e negociações.
          </p>

          <div className="mt-10 space-y-4">
            <div className="rounded-3xl bg-slate-900 p-5">
              <div className="font-semibold">Multiempresa</div>
              <div className="mt-1 text-sm text-slate-400">Controle várias imobiliárias com segurança.</div>
            </div>
            <div className="rounded-3xl bg-slate-900 p-5">
              <div className="font-semibold">Operação comercial</div>
              <div className="mt-1 text-sm text-slate-400">Acompanhe visitas, imóveis e negociações em um só lugar.</div>
            </div>
          </div>
        </div>

        <div className="p-6 sm:p-10 lg:p-12">
          <div className="mx-auto max-w-md">
            <h1 className="text-3xl font-bold tracking-tight text-slate-900">Entrar</h1>
            <p className="mt-2 text-sm text-slate-500">Acesse sua conta para continuar.</p>

            <form onSubmit={handleSubmit} className="mt-8 space-y-5">
              <div>
                <label className="mb-2 block text-sm font-medium text-slate-700">Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@empresa.com"
                  className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm"
                  required
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-slate-700">Senha</label>
                <input
                  type="password"
                  value={senha}
                  onChange={(e) => setSenha(e.target.value)}
                  placeholder="Digite sua senha"
                  className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm"
                  required
                />
              </div>

              {erro ? (
                <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                  {erro}
                </div>
              ) : null}

              <button
                className="w-full rounded-2xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-70"
                type="submit"
                disabled={loading}
              >
                {loading ? "Entrando..." : "Entrar"}
              </button>
            </form>

            <p className="mt-6 text-center text-sm text-slate-500">
              <Link to="/super-admin/login" className="font-medium text-blue-600 hover:text-blue-700">
                Entrar como super admin
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
