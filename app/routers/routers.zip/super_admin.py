from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.super_admin import SuperAdmin
from app.core.security import verify_password, create_access_token, hash_password
from app.schemas.super_admin import SuperAdminCreate, SuperAdminLogin, SuperAdminResponse

router = APIRouter(prefix="/super-admin", tags=["Super Admin"])


@router.post("/registrar", response_model=SuperAdminResponse)
def registrar_super_admin(payload: SuperAdminCreate, db: Session = Depends(get_db)):
    existente = db.query(SuperAdmin).filter(SuperAdmin.email == payload.email).first()
    if existente:
        raise HTTPException(status_code=400, detail="Email já cadastrado")

    dados = payload.model_dump()
    dados["senha"] = hash_password(dados["senha"])

    novo = SuperAdmin(**dados)
    db.add(novo)
    db.commit()
    db.refresh(novo)
    return novo


@router.post("/login")
def login_super_admin(payload: SuperAdminLogin, db: Session = Depends(get_db)):
    user = db.query(SuperAdmin).filter(SuperAdmin.email == payload.email).first()

    if not user or not verify_password(payload.senha, user.senha):
        raise HTTPException(status_code=401, detail="Credenciais inválidas")

    token = create_access_token({
        "sub": str(user.id),
        "tipo": "super_admin"
    })

    return {
        "access_token": token,
        "token_type": "bearer"
    }