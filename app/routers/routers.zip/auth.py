from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.corretor import Corretor
from app.models.empresa import Empresa
from app.core.security import verify_password, create_access_token, hash_password
from app.schemas.auth import LoginRequest, TokenResponse
from app.schemas.corretor import CorretorAdminCreate, CorretorResponse

router = APIRouter(prefix="/auth", tags=["Auth"])


@router.post("/registrar-admin", response_model=CorretorResponse)
def registrar_admin(corretor: CorretorAdminCreate, db: Session = Depends(get_db)):
    empresa = db.query(Empresa).filter(Empresa.id == corretor.empresa_id).first()
    if not empresa:
        raise HTTPException(status_code=404, detail="Empresa não encontrada")

    email_existente = db.query(Corretor).filter(Corretor.email == corretor.email).first()
    if email_existente:
        raise HTTPException(status_code=400, detail="Email já cadastrado")

    creci_existente = db.query(Corretor).filter(Corretor.creci == corretor.creci).first()
    if creci_existente:
        raise HTTPException(status_code=400, detail="CRECI já cadastrado")

    dados = corretor.model_dump()
    dados["senha"] = hash_password(dados["senha"])
    dados["perfil"] = "admin"

    novo_corretor = Corretor(**dados)
    db.add(novo_corretor)
    db.commit()
    db.refresh(novo_corretor)
    return novo_corretor


@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    corretor = db.query(Corretor).filter(Corretor.email == payload.email).first()

    if not corretor or not verify_password(payload.senha, corretor.senha):
        raise HTTPException(status_code=401, detail="Credenciais inválidas")

    token = create_access_token({
        "sub": str(corretor.id),
        "empresa_id": corretor.empresa_id
    })

    return {"access_token": token, "token_type": "bearer"}
