from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.deps import get_current_user, require_admin
from app.database import get_db
from app.models.imovel import Imovel
from app.models.corretor import Corretor
from app.schemas.imovel import ImovelCreate, ImovelResponse

router = APIRouter(prefix="/imoveis", tags=["Imóveis"])


@router.post("/", response_model=ImovelResponse)
def criar_imovel(
    imovel: ImovelCreate,
    db: Session = Depends(get_db),
    user: Corretor = Depends(get_current_user),
):
    if imovel.corretor_id is not None:
        corretor = (
            db.query(Corretor)
            .filter(Corretor.id == imovel.corretor_id, Corretor.empresa_id == user.empresa_id)
            .first()
        )
        if not corretor:
            raise HTTPException(status_code=404, detail="Corretor não encontrado na sua empresa")

    dados = imovel.model_dump()
    if user.perfil != "admin" and not dados.get("corretor_id"):
        dados["corretor_id"] = user.id
    dados["empresa_id"] = user.empresa_id

    novo_imovel = Imovel(**dados)
    db.add(novo_imovel)
    db.commit()
    db.refresh(novo_imovel)
    return novo_imovel


@router.get("/", response_model=list[ImovelResponse])
def listar_imoveis(
    db: Session = Depends(get_db),
    user: Corretor = Depends(get_current_user),
):
    query = db.query(Imovel).filter(Imovel.empresa_id == user.empresa_id)
    if user.perfil != "admin":
        query = query.filter(Imovel.corretor_id == user.id)
    return query.all()


@router.get("/{imovel_id}", response_model=ImovelResponse)
def buscar_imovel(
    imovel_id: int,
    db: Session = Depends(get_db),
    user: Corretor = Depends(get_current_user),
):
    query = db.query(Imovel).filter(Imovel.id == imovel_id, Imovel.empresa_id == user.empresa_id)
    if user.perfil != "admin":
        query = query.filter(Imovel.corretor_id == user.id)

    imovel = query.first()
    if not imovel:
        raise HTTPException(status_code=404, detail="Imóvel não encontrado")
    return imovel


@router.put("/{imovel_id}", response_model=ImovelResponse)
def atualizar_imovel(
    imovel_id: int,
    dados: ImovelCreate,
    db: Session = Depends(get_db),
    user: Corretor = Depends(get_current_user),
):
    query = db.query(Imovel).filter(Imovel.id == imovel_id, Imovel.empresa_id == user.empresa_id)
    if user.perfil != "admin":
        query = query.filter(Imovel.corretor_id == user.id)

    imovel = query.first()
    if not imovel:
        raise HTTPException(status_code=404, detail="Imóvel não encontrado")

    if dados.corretor_id is not None:
        corretor = (
            db.query(Corretor)
            .filter(Corretor.id == dados.corretor_id, Corretor.empresa_id == user.empresa_id)
            .first()
        )
        if not corretor:
            raise HTTPException(status_code=404, detail="Corretor não encontrado na sua empresa")

    payload = dados.model_dump()
    if user.perfil != "admin":
        payload["corretor_id"] = user.id

    for campo, valor in payload.items():
        setattr(imovel, campo, valor)

    db.commit()
    db.refresh(imovel)
    return imovel


@router.delete("/{imovel_id}")
def deletar_imovel(
    imovel_id: int,
    db: Session = Depends(get_db),
    user: Corretor = Depends(require_admin),
):
    imovel = (
        db.query(Imovel)
        .filter(Imovel.id == imovel_id, Imovel.empresa_id == user.empresa_id)
        .first()
    )
    if not imovel:
        raise HTTPException(status_code=404, detail="Imóvel não encontrado")

    db.delete(imovel)
    db.commit()
    return {"mensagem": "Imóvel removido com sucesso"}
