from io import BytesIO
from urllib.parse import quote

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import StreamingResponse, JSONResponse
from reportlab.lib.pagesizes import A4
from reportlab.lib.colors import HexColor, white
from reportlab.pdfgen import canvas
from reportlab.pdfbase.pdfmetrics import stringWidth
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.database import get_db
from app.models.corretor import Corretor
from app.models.empresa import Empresa
from app.models.imovel import Imovel
from app.models.imovel_midia import ImovelMidia
from app.services.imovel_compartilhamento import montar_texto_imovel_whatsapp, fmt_money

router = APIRouter(prefix="/imoveis", tags=["Imóveis - Compartilhamento"])

NAVY = HexColor("#0F2747")
SLATE = HexColor("#334155")
TEXT = HexColor("#0F172A")
MUTED = HexColor("#64748B")
LINE = HexColor("#E2E8F0")
CARD = HexColor("#F8FAFC")
ACCENT = HexColor("#1D4ED8")

def get_base_url(request: Request) -> str:
    return str(request.base_url).rstrip("/")

def buscar_imovel_empresa(db: Session, user: Corretor, imovel_id: int):
    query = db.query(Imovel).filter(Imovel.id == imovel_id, Imovel.empresa_id == user.empresa_id)
    if user.perfil != "admin":
        query = query.filter(Imovel.corretor_id == user.id)
    return query.first()

def _safe(value):
    return "-" if value in (None, "", []) else str(value)

def _wrap(c, text, width, font="Helvetica", size=10):
    words = str(text or "-").split()
    lines = []
    current = ""
    for word in words:
        test = word if not current else f"{current} {word}"
        if stringWidth(test, font, size) <= width:
            current = test
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines or ["-"]

def draw_label_value(c, x, y, w, label, value, height=36):
    c.setFillColor(CARD)
    c.setStrokeColor(LINE)
    c.roundRect(x, y - height, w, height, 10, stroke=1, fill=1)
    c.setFillColor(MUTED)
    c.setFont("Helvetica-Bold", 7.5)
    c.drawString(x + 10, y - 12, label.upper())
    c.setFillColor(TEXT)
    c.setFont("Helvetica", 10.5)
    txt = _safe(value)
    c.drawString(x + 10, y - 26, txt[:44])

def draw_section(c, title, y):
    c.setFillColor(TEXT)
    c.setFont("Helvetica-Bold", 13)
    c.drawString(42, y, title)
    c.setStrokeColor(LINE)
    c.line(42, y - 8, 553, y - 8)

def draw_multiline_card(c, x, y, w, title, value, min_height=70):
    lines = _wrap(c, value, w - 20, font="Helvetica", size=10.5)
    content_h = max(min_height, 24 + (len(lines) * 14) + 14)
    c.setFillColor(CARD)
    c.setStrokeColor(LINE)
    c.roundRect(x, y - content_h, w, content_h, 12, stroke=1, fill=1)
    c.setFillColor(MUTED)
    c.setFont("Helvetica-Bold", 8)
    c.drawString(x + 10, y - 14, title.upper())
    c.setFillColor(TEXT)
    c.setFont("Helvetica", 10.5)
    yy = y - 30
    for line in lines:
        c.drawString(x + 10, yy, line)
        yy -= 14
    return y - content_h

@router.get("/{imovel_id}/compartilhar")
def compartilhar_imovel(imovel_id: int, request: Request, db: Session = Depends(get_db), user: Corretor = Depends(get_current_user)):
    imovel = buscar_imovel_empresa(db, user, imovel_id)
    if not imovel:
        raise HTTPException(status_code=404, detail="Imóvel não encontrado")
    midias = db.query(ImovelMidia).filter(ImovelMidia.imovel_id == imovel_id).all()
    base_url = get_base_url(request)
    texto = montar_texto_imovel_whatsapp(imovel, midias, base_url)
    whatsapp_url = f"https://wa.me/?text={quote(texto)}"
    return JSONResponse({
        "texto": texto,
        "whatsapp_url": whatsapp_url,
        "pdf_url": f"{base_url}/imoveis/{imovel_id}/pdf",
        "detalhe_url": f"{base_url}/imoveis/{imovel_id}",
        "midias": [f"{base_url}{m.arquivo_url}" for m in midias],
    })

@router.get("/{imovel_id}/pdf")
def gerar_pdf_imovel(imovel_id: int, request: Request, db: Session = Depends(get_db), user: Corretor = Depends(get_current_user)):
    imovel = buscar_imovel_empresa(db, user, imovel_id)
    if not imovel:
        raise HTTPException(status_code=404, detail="Imóvel não encontrado")

    empresa = db.query(Empresa).filter(Empresa.id == user.empresa_id).first()

    buffer = BytesIO()
    c = canvas.Canvas(buffer, pagesize=A4)
    largura, altura = A4

    # Header / capa limpa
    c.setFillColor(NAVY)
    c.rect(0, altura - 120, largura, 120, stroke=0, fill=1)
    c.setFillColor(white)
    c.setFont("Helvetica-Bold", 22)
    c.drawString(42, altura - 42, empresa.nome if empresa else "Imobiliária")
    c.setFont("Helvetica", 10)
    c.drawString(42, altura - 60, "Apresentação comercial do imóvel")
    c.setFillColor(HexColor("#DDEAFE"))
    c.setFont("Helvetica-Bold", 24)
    c.drawString(42, altura - 96, imovel.titulo or "Imóvel")

    # bloco preço
    c.setFillColor(white)
    c.roundRect(380, altura - 98, 160, 46, 12, stroke=0, fill=1)
    c.setFillColor(ACCENT)
    c.setFont("Helvetica-Bold", 18)
    c.drawRightString(525, altura - 70, fmt_money(imovel.valor))

    y = altura - 150

    # Resumo executivo
    draw_section(c, "Resumo executivo", y)
    y -= 22
    draw_label_value(c, 42, y, 160, "Tipo", imovel.tipo)
    draw_label_value(c, 216, y, 160, "Finalidade", imovel.finalidade)
    draw_label_value(c, 390, y, 150, "Status", imovel.status)

    y -= 48
    draw_label_value(c, 42, y, 160, "Quartos", imovel.quartos)
    draw_label_value(c, 216, y, 160, "Banheiros", imovel.banheiros)
    draw_label_value(c, 390, y, 150, "Vagas", imovel.vagas)

    y -= 48
    draw_multiline_card(c, 42, y, 498, "Localização", f"{_safe(imovel.endereco)} • {_safe(imovel.bairro)} • {_safe(imovel.cidade)}", min_height=58)
    y -= 74

    # Descrição
    draw_section(c, "Descrição do imóvel", y)
    y -= 20
    y = draw_multiline_card(c, 42, y, 498, "Descrição", imovel.descricao or "Não informado.", min_height=100) - 16

    # Informações rurais
    draw_section(c, "Informações rurais / fazenda", y)
    y -= 22
    rural = [
        ("Área em hectares", getattr(imovel, "area_hectares", None)),
        ("Área em alqueires", getattr(imovel, "area_alqueires", None)),
        ("Distância do asfalto (km)", getattr(imovel, "distancia_asfalto_km", None)),
        ("Distância da cidade (km)", getattr(imovel, "distancia_cidade_km", None)),
        ("Área agricultável", getattr(imovel, "area_agricultavel", None)),
        ("Área inaproveitável", getattr(imovel, "area_inaproveitavel", None)),
    ]
    for i in range(0, len(rural), 2):
        left = rural[i]
        right = rural[i + 1] if i + 1 < len(rural) else ("", "")
        draw_label_value(c, 42, y, 240, left[0], left[1])
        draw_label_value(c, 300, y, 240, right[0], right[1])
        y -= 48

    y = draw_multiline_card(c, 42, y, 498, "Plantio existente", getattr(imovel, "plantio_existente", None) or "Não informado.", min_height=70) - 18

    # Página 2 com ficha técnica completa no mesmo padrão
    c.showPage()
    c.setFillColor(NAVY)
    c.rect(0, altura - 74, largura, 74, stroke=0, fill=1)
    c.setFillColor(white)
    c.setFont("Helvetica-Bold", 18)
    c.drawString(42, altura - 42, "Ficha técnica completa")

    y = altura - 102
    all_fields = [
        ("Título", imovel.titulo),
        ("Valor", fmt_money(imovel.valor)),
        ("Tipo", imovel.tipo),
        ("Finalidade", imovel.finalidade),
        ("Status", imovel.status),
        ("Endereço", imovel.endereco),
        ("Bairro", imovel.bairro),
        ("Cidade", imovel.cidade),
        ("Quartos", imovel.quartos),
        ("Banheiros", imovel.banheiros),
        ("Vagas", imovel.vagas),
        ("Área em hectares", getattr(imovel, "area_hectares", None)),
        ("Área em alqueires", getattr(imovel, "area_alqueires", None)),
        ("Distância do asfalto (km)", getattr(imovel, "distancia_asfalto_km", None)),
        ("Distância da cidade (km)", getattr(imovel, "distancia_cidade_km", None)),
        ("Área agricultável", getattr(imovel, "area_agricultavel", None)),
        ("Área inaproveitável", getattr(imovel, "area_inaproveitavel", None)),
        ("Plantio existente", getattr(imovel, "plantio_existente", None)),
        ("Descrição", imovel.descricao),
    ]
    col_x = [42, 300]
    idx = 0
    for label, value in all_fields:
        x = col_x[idx % 2]
        if label in ("Plantio existente", "Descrição"):
            if idx % 2 != 0:
                y -= 48
                idx += 1
            y = draw_multiline_card(c, 42, y, 498, label, value or "Não informado.", min_height=82) - 14
            idx = 0
            continue
        draw_label_value(c, x, y, 240, label, value)
        idx += 1
        if idx % 2 == 0:
            y -= 48
        if y < 90:
            c.showPage()
            c.setFillColor(NAVY)
            c.rect(0, altura - 54, largura, 54, stroke=0, fill=1)
            c.setFillColor(white)
            c.setFont("Helvetica-Bold", 14)
            c.drawString(42, altura - 34, "Ficha técnica completa")
            y = altura - 82
            idx = 0

    # rodapé
    c.setFillColor(SLATE)
    c.setFont("Helvetica", 9)
    c.drawString(42, 20, f"Documento gerado por {empresa.nome if empresa else 'Imobiliária'}")
    c.drawRightString(largura - 42, 20, f"Imóvel #{imovel.id}")

    c.save()
    buffer.seek(0)
    return StreamingResponse(
        buffer,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="imovel_{imovel.id}.pdf"'},
    )
