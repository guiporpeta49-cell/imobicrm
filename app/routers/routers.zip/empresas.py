from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.empresa import Empresa
from app.schemas.empresa import EmpresaCreate, EmpresaResponse
from app.core.super_admin_deps import get_current_super_admin
from app.models.super_admin import SuperAdmin

router = APIRouter(prefix="/empresas", tags=["Empresas"])


@router.post("/", response_model=EmpresaResponse)
def criar_empresa(
    empresa: EmpresaCreate,
    db: Session = Depends(get_db),
    admin: SuperAdmin = Depends(get_current_super_admin),
):
    if empresa.email:
        email_existente = db.query(Empresa).filter(Empresa.email == empresa.email).first()
        if email_existente:
            raise HTTPException(status_code=400, detail="Email da empresa já cadastrado")

    if empresa.cnpj:
        cnpj_existente = db.query(Empresa).filter(Empresa.cnpj == empresa.cnpj).first()
        if cnpj_existente:
            raise HTTPException(status_code=400, detail="CNPJ já cadastrado")

    nova_empresa = Empresa(**empresa.model_dump())
    db.add(nova_empresa)
    db.commit()
    db.refresh(nova_empresa)
    return nova_empresa


@router.get("/", response_model=list[EmpresaResponse])
def listar_empresas(
    db: Session = Depends(get_db),
    admin: SuperAdmin = Depends(get_current_super_admin),
):
    return db.query(Empresa).all()


@router.get("/{empresa_id}", response_model=EmpresaResponse)
def buscar_empresa(
    empresa_id: int,
    db: Session = Depends(get_db),
    admin: SuperAdmin = Depends(get_current_super_admin),
):
    empresa = db.query(Empresa).filter(Empresa.id == empresa_id).first()
    if not empresa:
        raise HTTPException(status_code=404, detail="Empresa não encontrada")
    return empresa


@router.put("/{empresa_id}", response_model=EmpresaResponse)
def atualizar_empresa(
    empresa_id: int,
    dados: EmpresaCreate,
    db: Session = Depends(get_db),
    admin: SuperAdmin = Depends(get_current_super_admin),
):
    empresa = db.query(Empresa).filter(Empresa.id == empresa_id).first()
    if not empresa:
        raise HTTPException(status_code=404, detail="Empresa não encontrada")

    for campo, valor in dados.model_dump().items():
        setattr(empresa, campo, valor)

    db.commit()
    db.refresh(empresa)
    return empresa


@router.delete("/{empresa_id}")
def deletar_empresa(
    empresa_id: int,
    db: Session = Depends(get_db),
    admin: SuperAdmin = Depends(get_current_super_admin),
):
    empresa = db.query(Empresa).filter(Empresa.id == empresa_id).first()
    if not empresa:
        raise HTTPException(status_code=404, detail="Empresa não encontrada")

    db.delete(empresa)
    db.commit()
    return {"mensagem": "Empresa removida com sucesso"}